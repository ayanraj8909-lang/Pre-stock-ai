/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Upload, 
  Clipboard, 
  Copy, 
  Check, 
  RefreshCw, 
  Image as ImageIcon,
  AlertCircle,
  Package
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SYSTEM_PROMPT = `
You are a highly precise stock data extractor. 
Your task is to analyze the provided image (which could be a spreadsheet, a dashboard, or a system screenshot) and extract "Pre stock" information.

RULES:
1. Look for data labeled as "Pre stock" or "online saleable" (which contributes to pre-stock).
2. Extract the Size and Quantity.
3. OUTPUT FORMAT: Each size followed by a hyphen and the quantity (e.g., "38-5").
4. IMPORTANT: Only include sizes that have a non-zero quantity in "Pre stock".
5. IMPORTANT: You MUST append the text "Pre stock" at the very end of the list after a blank line.
6. DO NOT add any extra labels, headers, or conversational text.
7. The output should look EXACTLY like this (example):
38-5
40-2
42-11
44-21
46-7
48-9

Pre stock

8. If no pre-stock data is found, return "No Pre stock found".
`;

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle Image Selection
  const handleImageUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      setImage(e.target?.result as string);
      processImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Process with Gemini
  const processImage = async (base64String: string) => {
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const base64Data = base64String.split(',')[1];
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType: "image/png" } },
            { text: SYSTEM_PROMPT }
          ],
        },
      });

      const text = response.text;
      if (text) {
        setResult(text.trim());
      } else {
        setError('Could not extract data. Please try a clearer image.');
      }
    } catch (err) {
      console.error(err);
      setError('An error occurred while processing the image.');
    } finally {
      setLoading(false);
    }
  };

  // Clipboard Paste Support
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (items) {
        for (let i = 0; i < items.length; i++) {
          if (items[i].type.indexOf('image') !== -1) {
            const blob = items[i].getAsFile();
            if (blob) handleImageUpload(blob);
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] text-[#1D1D1F] font-sans selection:bg-blue-100 p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <header className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-3">
            <div className="bg-black p-2 rounded-xl">
              <Package className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">StockSnap</h1>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">Rayhan Edition</p>
            </div>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-[10px] text-gray-400 font-mono">v1.0.4 - STABLE</p>
          </div>
        </header>

        <main className="space-y-6">
          <AnimatePresence mode="wait">
            {!image ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative"
              >
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="group cursor-pointer aspect-video bg-white border-2 border-dashed border-gray-200 rounded-3xl flex flex-col items-center justify-center gap-6 transition-all hover:border-black active:scale-[0.99] overflow-hidden"
                >
                  <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-[0.02] transition-opacity" />
                  <div className="w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Upload className="text-gray-400 group-hover:text-black transition-colors" />
                  </div>
                  <div className="text-center">
                    <h3 className="text-lg font-semibold">Upload Stock Screenshot</h3>
                    <p className="text-sm text-gray-400 mt-1">Drag and drop, paste from clipboard, or click to browse</p>
                  </div>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  className="hidden" 
                  accept="image/*"
                  onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
                />
              </motion.div>
            ) : (
              <motion.div
                key="processing"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="grid md:grid-cols-2 gap-6"
              >
                {/* Image Preview */}
                <div className="bg-white p-4 rounded-3xl shadow-sm space-y-4 border border-gray-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Captured Source</span>
                    <button 
                      onClick={reset}
                      className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Reset"
                    >
                      <RefreshCw className="w-4 h-4 text-gray-500" />
                    </button>
                  </div>
                  <div className="aspect-video bg-gray-50 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
                    <img src={image} alt="Source" className="w-full h-full object-contain" />
                  </div>
                </div>

                {/* Results Panel */}
                <div className="bg-white p-4 rounded-3xl shadow-sm space-y-4 border border-gray-100 flex flex-col">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Extracted Output</span>
                    {result && (
                      <button 
                        onClick={copyToClipboard}
                        className="flex items-center gap-1.5 px-3 py-1 bg-black text-white rounded-lg text-xs font-medium hover:bg-gray-800 transition-colors active:scale-95"
                      >
                        {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        {copied ? 'Copied' : 'Copy'}
                      </button>
                    )}
                  </div>

                  <div className="flex-1 min-h-[200px] flex flex-col">
                    {loading ? (
                      <div className="flex-1 flex flex-col items-center justify-center gap-4 text-gray-400">
                        <RefreshCw className="w-8 h-8 animate-spin" />
                        <span className="text-xs font-medium animate-pulse">Analyzing Stock Data...</span>
                      </div>
                    ) : error ? (
                      <div className="flex-1 flex flex-col items-center justify-center gap-3 text-red-500 bg-red-50 rounded-2xl p-6 text-center">
                        <AlertCircle className="w-8 h-8" />
                        <span className="text-sm font-medium">{error}</span>
                        <button 
                          onClick={() => processImage(image)}
                          className="text-xs underline font-semibold mt-2 hover:text-red-700"
                        >
                          Retry Processing
                        </button>
                      </div>
                    ) : (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="flex-1 bg-gray-50 rounded-2xl p-6 font-mono text-sm leading-relaxed whitespace-pre"
                      >
                        {result}
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Footer */}
        <footer className="mt-16 text-center space-y-2">
          <p className="text-xs text-gray-400 font-medium">Developed with precision by <span className="text-black font-bold">Rayhan</span></p>
          <p className="text-[10px] text-gray-300">© 2026 StockSnap. Optimized for professional stock management.</p>
        </footer>
      </div>
    </div>
  );
}
